package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Prod;

@Repository
@Transactional
public class ProdImpl implements ProdRep {

	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	public void saveProduct(Prod product) {
		em.persist(product);
	}

	
}
