package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Prod;
import com.cg.repo.ProdRep;

@Controller
public class ProductController {

	@Autowired
	private ProdRep repo;
	
	
	@GetMapping("/addproduct")
	public String sayHello(Model model) {
		model.addAttribute("productdetails", new Prod());
		return "product";
	}
	
	@RequestMapping("addproduct")
	public String addProduct(@ModelAttribute("productdetails") Prod prod, Model model) {
		model.addAttribute("productdetails", new Prod());
		
		repo.saveProduct(prod);

		return "productadded";

	}
	

	
}
